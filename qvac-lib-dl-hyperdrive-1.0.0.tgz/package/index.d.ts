import Corestore from 'corestore'
import BaseDL from 'qvac-lib-dl-base'

declare interface HyperDriveOptions {
  key: string
  store?: Corestore
}

declare class HyperDriveDL extends BaseDL {
  constructor(opts: HyperDriveOptions)

  /**
   * Initializes the Hyperdrive client.
   * @returns {Promise<void>}
   */
  ready(): Promise<void>

  /**
   * Stops the Hyperdrive client.
   * @returns {Promise<void>}
   */
  close(): Promise<void>

  /**
   * Returns a readable stream for a given file path from Hyperdrive.
   * @param {string} path - The file path inside the Hyperdrive.
   * @returns {Promise<Readable>} A readable stream for the specified file.
   */
  getStream(path: string): Promise<ReadableStream>

    /**
   * Get the size of a file in bytes.
   * @param {string} path - The file path inside the Hyperdrive.
   * @returns {Promise<number>} The size of the file in bytes.
   */
  getFileSize (path: string): Promise<number>

  /**
   * Lists the files in a given directory in the Hyperdrive.
   * @param {string} [directoryPath='/'] - The directory to list files from. Defaults to '/'.
   * @returns {Promise<string[]>} A list of file names in the directory.
   */
  list(directoryPath?: string): Promise<string[]>
}

declare namespace HyperDriveDL {
  export { HyperDriveDL as default, HyperDriveOptions }
}

export = HyperDriveDL
