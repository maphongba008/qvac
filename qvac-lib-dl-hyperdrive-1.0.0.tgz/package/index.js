'use strict'

const Corestore = require('corestore')
const Hyperdrive = require('hyperdrive')
const Hyperswarm = require('hyperswarm')
const BaseDL = require('qvac-lib-dl-base')
const RAM = require('random-access-memory')

const HYPERDRIVE_PROTOCOL_PREFIX = 'hd://'

/**
 * @typedef {Object} HyperDriveOptions
 * @property {string} key - The key for the Hyperdrive, must start with the `hd://` prefix.
 * @property {Corestore} [store] - An optional Corestore instance. If not provided, a new Corestore using RAM will be created.
 */

/**
 * HyperDriveDL class for handling Hyperdrive-based downloads.
 * @extends {BaseDL}
 */
class HyperDriveDL extends BaseDL {
  /**
   * Create a new HyperDriveDL instance.
   * @param {HyperDriveOptions} opts - Options for the Hyperdrive downloader.
   * @throws {Error} If opts is not an object, doesn't contain a key, or if the key is invalid.
   */
  constructor (opts) {
    super(opts)

    if (!('key' in opts)) {
      throw new Error('ERR_KEY_REQUIRED')
    }

    if (!opts.key.startsWith(HYPERDRIVE_PROTOCOL_PREFIX)) {
      throw new Error('ERR_KEY_INVALID')
    }

    this.swarm = new Hyperswarm()
  }

  /**
   * Start the Hyperdrive client.
   * @returns {Promise<void>}
   */
  async _open () {
    const keyWithoutPrefix = this.opts.key.substring(
      HYPERDRIVE_PROTOCOL_PREFIX.length
    )

    const store = this.opts.store || new Corestore(RAM)

    this.swarm.on('connection', (conn) => store.replicate(conn))

    this.client = new Hyperdrive(store, Buffer.from(keyWithoutPrefix, 'hex'))
    await this.client.ready()

    const foundPeers = store.findingPeers()

    this.swarm.join(this.client.discoveryKey, { client: true, server: false })

    // Awaiting this promise is unnecessary and slow
    this.swarm.flush()

    foundPeers()
  }

  /**
   * Stop the Hyperdrive client.
   * @returns {Promise<void>}
   */
  async _close () {
    if (this.client) {
      await this.client.close()
    }

    if (this.swarm) {
      await this.swarm.destroy()
    }
  }

  /**
   * Get a readable stream for a given file path from Hyperdrive.
   * @param {string} filePath - The file path inside the Hyperdrive.
   * @returns {Promise<ReadableStream>} A readable stream for the specified file.
   */
  async getStream (filePath) {
    return this.client.createReadStream(filePath)
  }

  /**
   * Get the size of a file in bytes.
   * @param {string} filePath - The file path inside the Hyperdrive.
   * @returns {Promise<number>} The size of the file in bytes.
   */
  async getFileSize (path) {
    const entry = await this.client.entry(path)
    if (entry?.value?.blob) {
      return entry.value.blob.byteLength
    } else {
      throw new Error('ERR_FILE_NOT_FOUND')
    }
  }

  /**
   * List the files in a given directory in the Hyperdrive.
   * @param {string} [directoryPath='/'] - The directory to list files from.
   * @returns {Promise<string[]>} A list of file names in the directory.
   */
  async list (directoryPath = '/') {
    const filesStream = this.client.list(directoryPath, { recursive: true })

    const files = []
    for await (const file of filesStream) {
      files.push(file.key)
    }

    return files
  }
}

module.exports = HyperDriveDL
