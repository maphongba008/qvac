'use strict'

const test = require('brittle')
const sinon = require('sinon')
const HyperDriveDL = require('..')

const HYPERDRIVE_PROTOCOL_PREFIX = 'hd://'

test('Constructor - Valid Hyperdrive Key', function (t) {
  const validKey = `${HYPERDRIVE_PROTOCOL_PREFIX}abcdef1234567890abcdef1234567890`

  t.execution(
    () => new HyperDriveDL({ key: validKey }),
    'Should not throw with a valid key'
  )
  t.pass('Constructor initialized with valid key')
})

test('Constructor - Invalid Hyperdrive Key', function (t) {
  const invalidKey = 'invalid://abcdef1234567890'

  t.exception(
    () => new HyperDriveDL({ key: invalidKey }),
    /ERR_KEY_INVALID/,
    'Should throw error for invalid protocol'
  )
})

test('Stream Handling - Get Stream', async function (t) {
  const validKey = `${HYPERDRIVE_PROTOCOL_PREFIX}abcdef1234567890abcdef1234567890`
  const hyperDriveDL = new HyperDriveDL({ key: validKey })
  const path = '/test/path'

  hyperDriveDL.client = {
    createReadStream: sinon.stub().returns('stream')
  }

  const stream = await hyperDriveDL.getStream(path)

  t.ok(
    hyperDriveDL.client.createReadStream.calledOnceWith(path),
    'createReadStream should be called with correct path'
  )

  t.is(stream, 'stream', 'Should return the correct stream')
})

test('Stream Handling - Error on Get Stream', async function (t) {
  const validKey = `${HYPERDRIVE_PROTOCOL_PREFIX}abcdef1234567890abcdef1234567890`
  const hyperDriveDL = new HyperDriveDL({ key: validKey })
  const path = '/invalid/path'

  hyperDriveDL.client = {
    createReadStream: sinon.stub().throws(new Error('Stream error'))
  }

  await t.exception(
    async () => await hyperDriveDL.getStream(path),
    /Stream error/,
    'Should throw an error on invalid path'
  )
})
