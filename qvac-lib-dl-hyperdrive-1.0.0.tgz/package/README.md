# qvac-lib-dl-hyperdrive

`qvac-lib-dl-hyperdrive` is a data loading library designed to load model weights and other resources from a Hyperdrive instance. It leverages the `Hyperdrive` distributed file system for efficient peer-to-peer file sharing, enabling dynamic loading of files required for AI model inference, training, and other operations.

## Usage

### HyperDriveDL Class

`HyperDriveDL` extends `BaseDL` to provide a unified interface for loading files from a Hyperdrive instance. It integrates seamlessly with other QVAC AI Runtime libraries and classes.

#### Constructor:

```javascript
const HyperDriveDL = require("qvac-lib-dl-hyperdrive");

const hdDL = new HyperDriveDL({ key: "hd://your_hyperdrive_key" });
```

- **`key`**: A string representing the Hyperdrive key with the `hd://` protocol prefix.
- **`store`** (optional): A `Corestore` instance for managing storage. If not provided, the Hyperdrive will use an in-memory store.

#### Methods:

- **`ready()`**: Initializes the Hyperdrive client. This method must be called before interacting with the Hyperdrive.

  ```javascript
  await hdDL.ready();
  ```

- **`getStream(path)`**: Asynchronously retrieves a readable stream for a specified file path in the Hyperdrive.

  ```javascript
  const stream = await hdDL.getStream("/path/to/file");
  ```

- **`list(directoryPath)`**: Asynchronously lists files in a given directory in the Hyperdrive. By default, it lists files from the root directory.

  ```javascript
  const files = await hdDL.list("/");
  console.log(files); // Output: ['file1.bin', 'file2.bin']
  ```

- **`close()`**: Stops the Hyperdrive client and releases resources.

  ```javascript
  await hdDL.close();
  ```

## Examples

### Loading Models with QVAC Runtime

Below is an example of how `HyperDriveDL` can be used within the QVAC AI Runtime to dynamically load models:

```javascript
const Qvac = require("qvac-rt-local");
const HyperDriveDL = require("qvac-lib-dl-hyperdrive");
const MLCWhisper = require("qvac-lib-inference-addon-mlc-whisper");

const qvac = new Qvac({
  /* runtime options */
});

// Create an inference instance for Whisper using Hyperdrive to load weights
const whisper = qvac.inference.add(
  new MLCWhisper({
    weights: new HyperDriveDL({ key: "hd://your_hyperdrive_key" }),
    params: {
      /* model parameters */
    },
  })
);

// Load model weights
await whisper.load();
```

### HyperDriveDL in AI Models

The `HyperDriveDL` class can be integrated directly within model classes to dynamically fetch and load model files from a Hyperdrive instance.

```javascript
class MyModel {
  constructor(loader) {
    this.loader = loader;
  }

  async load() {
    const weightsStream = await this.loader.getStream("model_weights.bin");
    // Process all the required files from the stream...
  }
}
```

### Script Usage

This repository includes a script that allows you to serve files from a specified folder over Hyperdrive. To run the script using npm:

1. **Run the script with a folder path argument:**

   ```bash
   npm run hd-provider -- ./path/to/model/files ./path/to/storage(optional)
   ```

   This command will start serving files from the specified folder over Hyperdrive and output the Hyperdrive key, which can be used by clients to access the files.

   The path to storage is optional. If it's not provided, the files will be served from memory.

## Development

1. Install dependencies:

   ```bash
   npm install
   ```

2. Run unit tests:

   ```bash
   npm test
   ```
   