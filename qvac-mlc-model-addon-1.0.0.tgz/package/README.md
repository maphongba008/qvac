# QVAC MLC Model Addon

Template project to setup QVAC MLC models that can be loaded into Bare as native
addons. Remember to change `package.json` with your model's name.

This addon relies on MLC LLM's functionality to compile a model into object
files. These object files are then compiled into a Bare addon which can then be
loaded in all the platforms supported by Bare dynamically.

## Usage

1. Use MLC LLM to compile the model to object files, namely `devc.o` and `lib0.o`.

```sh
$ mlc_llm compile --quantization QX --host HOST --output OUTPUT.tar MODEL_PATH
```

- `QX` is the preferred quantization.
- `HOST` is the target architecture in LLVM triplet format. See `rustup target
list` for an idea of this value.
- `OUTPUT.tar` is the path to output archive that will contain the object files.
- `MODEL_PATH` is the path to configured model (the stage after `mlc_llm gen_config`).

2. Copy the object files from `OUTPUT.tar` to the appropriate directory in
   [`models/`](models/).
3. It may not be possible to get the model compiled for all targets as required
   by Bare. For example, Bare might need the model for `x86_64-apple-darwin` but
   MLC may not support it. If you know that you will never use the addon on that
   target, then feel free to use placeholder object files.

```sh
$ touch devc.c # Same process for lib0.o
$ clang -target HOST -c devc.c
$ file devc.o # Should be of required format
```

4. Compile it as a usual Bare native addon.

```sh
$ bare-make generate
$ bare-make build
$ bare-make install
$ npm pack # Or publish it in your preferred method
```

5. Install the addon in the appropriate project.
6. To get the path to model's dynamic library, use the path returned by
   `QVACMLCModelAddon.resolve()`.

```javascript
// Use your model's name as per its package.json
const QVACMLCModelAddon = require("qvac-mlc-model-addon");
const path = QVAMLCModelAddon.resolve();
```

Due to the way the addon is bundled in Bare, the path may or may not have
`.bare` extension. So ensure that that you force to load the dynamic library
through the platform's dynamic library loader irrespective of what the extension says.
