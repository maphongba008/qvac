module.exports = require.addon.resolve(".");
