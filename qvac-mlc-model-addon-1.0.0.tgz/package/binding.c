#include <bare.h>
#include <js.h>

static js_value_t *
qvac_mlc_model_addon_exports (js_env_t *env, js_value_t *exports) {
  return exports;
}

BARE_MODULE(qvac_mlc_model_addon, qvac_mlc_model_addon_exports)
